class Task {
  String name;
  String priority;
  DateTime deadline;

  Task({required this.name, required this.priority, required this.deadline});
}
