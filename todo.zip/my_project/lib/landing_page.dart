import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'task_model.dart';
import 'view_task.dart';
import 'Register.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  List<Task> tasks = [];

  // ✅ Open Add Task Popup
  void _openAddTaskDialog() {
    String taskName = '';
    String priority = 'High';
    DateTime? deadline;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Center(
              child: AlertDialog(
                backgroundColor: const Color.fromARGB(255, 253, 222, 232),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                title: Text("Add New Task"),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        decoration: InputDecoration(labelText: "Task Name"),
                        onChanged: (value) => taskName = value,
                      ),
                      SizedBox(height: 12),
                      DropdownButton<String>(
                        value: priority,
                        items: ["High", "Medium", "Low"]
                            .map(
                              (p) => DropdownMenuItem(value: p, child: Text(p)),
                            )
                            .toList(),
                        onChanged: (value) {
                          setDialogState(() {
                            priority = value!;
                          });
                        },
                      ),
                      SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            deadline == null
                                ? "No date selected "
                                : DateFormat.yMMMd().format(deadline!),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color.fromARGB(255, 255, 123, 167)
                            ),
                            onPressed: () async {
                              DateTime? picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(2023),
                                lastDate: DateTime(2030),
                              );
                              if (picked != null) {
                                setDialogState(() {
                                  deadline = picked;
                                });
                              }
                            },
                            child: Text("Pick Date",style: TextStyle(color: Colors.white)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text("Cancel"),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 255, 123, 167)
                    ),
                    onPressed: () {
                      if (taskName.isNotEmpty && deadline != null) {
                        setState(() {
                          tasks.add(
                            Task(
                              name: taskName,
                              priority: priority,
                              deadline: deadline!,
                            ),
                          );
                        });
                        Navigator.pop(context);
                      }
                    },
                    child: Text("Add",style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ✅ Navigate to View Tasks Page
  void _viewTask() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ViewTask(tasks: tasks)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "ToDo for Kido",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        automaticallyImplyLeading: false, // removes back button
        backgroundColor: Color.fromARGB(255, 165, 132, 255),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => Register(),
                ), 
              );
            },
            tooltip: "Logout",
          ),
        ],
      ),

      body: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.2,
              child: Image.asset('assets/images/image2.jpg', fit: BoxFit.cover),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    '"Organize your day, own your dreams!"',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 24),
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      onPressed: _viewTask,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 165, 132, 255),
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text(
                        "View My Tasks",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: _openAddTaskDialog,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 252, 113, 159),
                        minimumSize: Size(double.infinity, 50),
                      ),
                      child: Text(
                        "Add New Task",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
