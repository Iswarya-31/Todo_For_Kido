import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'task_model.dart';

class ViewTask extends StatefulWidget {
  final List<Task> tasks;
  ViewTask({required this.tasks});

  @override
  _ViewTaskState createState() => _ViewTaskState();
}

class _ViewTaskState extends State<ViewTask> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Tasks")),
      body: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.10,
              child: Image.asset('images/image3.jpg', fit: BoxFit.cover),
            ),
          ),
          widget.tasks.isEmpty
              ? Center(child: Text("No tasks added yet!"))
              : ListView.builder(
                  itemCount: widget.tasks.length,
                  itemBuilder: (context, index) {
                    final task = widget.tasks[index];
                    return Card(
                      margin: EdgeInsets.all(8),
                      child: ListTile(
                        title: Text(task.name),
                        subtitle: Text(
                          "${task.priority} | ${DateFormat.yMMMd().format(task.deadline)}",
                        ),
                        trailing: GestureDetector(
                          onTap: () {
                            setState(() {
                              widget.tasks.removeAt(index);
                            });
                          },
                          child: CircleAvatar(
                            radius: 15,
                            backgroundColor:  Color.fromARGB(255, 252, 113, 159),
                            child: Icon(Icons.check, color: Colors.white),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }
}
